﻿using System;
using System.Collections.Generic;

namespace HotelwebLisMVC.Models
{
    public partial class LedgerType
    {
        public int LedgerTypeId { get; set; }
        public string? LedgerTypeName { get; set; }
    }
}
